package ru.otus.study.chat;

import java.io.IOException;

public class ClientApplication {
    public static void main(String[] args) throws IOException {
        new Client();
    }
}
