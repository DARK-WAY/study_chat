package ru.otus.study.chat;

public enum RolesUsers {
    USER,
    ADMIN
}
